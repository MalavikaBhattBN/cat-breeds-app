"use client"
import { getBreeds } from "@/actions/getBreeds";
import { getCats } from "@/actions/getCats";
import { searchBreeds } from "@/actions/searchBreeds";
import { Autocomplete, Skeleton, TextField } from "@mui/material";
import { useEffect, useState } from "react";

interface Breeds {
    id: string,
    name: string,
    origin: string,
    temperament: string
}

interface SearchBarProps {
    onSelect: (breedId: string | null) => void;
}


const SearchBar = ({ onSelect }: SearchBarProps) => {
    const [breeds, setBreeds] = useState<Breeds[]>([]);
    const [hydrated, setHydrated] = useState(false);

    useEffect(() => {
        setHydrated(true);
        getBreeds().then((data) => {
            setBreeds(data.map((b: any) => ({ id: b.id, name: b.name })))
        }
        );
    }, []);

    const handleInputChange = async (_: any, value: string) => {
        // if(value.length < 2) return;
        // console.log("handleinputchange",value)
        // const breeds = await searchBreeds(value);
        // console.log("breeds response",breeds);
        let searchId;
        breeds.map((breed: any) => {
            if (breed.name === value) {
                searchId = breed.id;
            }

        })
        console.log(" const searchId", searchId)
        // const searchedbreeds = await searchBreeds(searchId);
        const searchedbreeds = await getCats(0,12,searchId);
        console.log("searchedbreeds",searchedbreeds)
    }

    if (!hydrated) {
        return <Skeleton variant="rectangular" width={200} height={40} />;
    }

    return (
        <Autocomplete
            disablePortal
            options={breeds}
            sx={{ width: 300, display: "flex", justifyContent: "center", alignItems: "center", mt: { xs: 2, sm: 4 }, mb: { xs: 2, sm: 4 } }}
            getOptionLabel={(option) => option.name}
            getOptionKey={(option) => option.id}
            onChange={(_, value) => onSelect(value ? value.id : null)}
        //    onInputChange={handleInputChange}
            renderInput={(params) => <TextField {...params} label="Choose a breed" />}
        />
    )
}

export default SearchBar;