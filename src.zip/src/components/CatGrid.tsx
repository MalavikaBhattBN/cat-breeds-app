"use client"
import { getCats } from "@/actions/getCats";
import { Box, CircularProgress } from "@mui/material";
import Grid from "@mui/material/Grid";
import { useEffect, useState } from "react";
import CatCard from "./CatCard";
import { useInView } from "react-intersection-observer";
import SearchBar from "./SearchBar";
import { searchBreeds } from "@/actions/searchBreeds";


interface CatGridProps {
    initialList: any[];
}

const CATS_LOAD_LIMIT = 12;


const CatGrid = ({ initialList }: CatGridProps) => {   
    const [cats, setCats] = useState(initialList);
    const [page, setPage] = useState(1);
    const [breedId, setBreedId] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { ref, inView } = useInView();


    const loadMoreCats = async () => {
        if (loading) return;
        setLoading(true);

        const newCats = await getCats(page, CATS_LOAD_LIMIT);
        console.log("loadMoreCats",newCats)
        setCats((prev) => [...prev, ...newCats]);
        setPage((prev) => prev + 1);


        setLoading(false);
    };
   //console.log("newCats", cats)

    const handleSelect = async (newBreedId: string | null) => {
      //  console.log("handleSelect",newBreedId)
        setBreedId(newBreedId);
        setPage(1);

        const searchedCats = await searchBreeds(newBreedId);
      //  const searchedCats = await getCats(0,CATS_LOAD_LIMIT,newBreedId);       
          //setCats(() => [...searchedCats]);
       // console.log("newCats", searchedCats)
         setCats([searchedCats]);
    }


    useEffect(() => {
        if (inView && !loading) {
            loadMoreCats();
        }
    }, [inView, loading]);

    console.log("cats", cats)

    return (
        <Box>
            <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", width: "100%", mt: { xs: 2, sm: 4 }, mb: { xs: 2, sm: 4 } }}>
                <SearchBar onSelect={handleSelect} />
            </Box>
            <Box>
                <Grid container spacing={4}>
                    {cats.map((cat: any) => (
                        <Grid size={{ xs: 12, sm: 6, md: 4, lg: 3 }} key={cat.id}>
                            <CatCard url={cat.url} breed={cat.breeds && cat.breeds.length > 0 ? cat.breeds[0] : undefined} />
                        </Grid>
                    ))}
                </Grid>
            </Box>
            <Box ref={ref} sx={{ display: "flex", justifyContent: "center", my: 2 }}>
                {loading && <CircularProgress />}
            </Box>
        </Box>
    )

}

export default CatGrid;