export const BASE_URL = "https://api.thecatapi.com/v1";
export const API_KEY = process.env.CAT_API_KEY as string;