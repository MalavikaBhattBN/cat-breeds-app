import { createTheme } from "@mui/material/styles";

export const theme = createTheme({
  palette: {
    primary: { main: "#0097A7", dark: "#006064", light: "#00BCD4" },
    secondary: { main: "#f50057" },
  },
  typography: {
    fontFamily: "Inter, sans-serif",
    fontSize: 12
  }
});