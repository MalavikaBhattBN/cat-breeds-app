import { API_KEY, BASE_URL } from "@/lib/catApi"
import { Cat } from "@/types";

/**searchCats Api returns the breed details of the searched breed */
const searchCats = async (breedId?: any) => {
    const url = new URL(`${BASE_URL}/breeds/${breedId}`);

    //url.searchParams.set("breed_ids", breedId);

    console.log("url searchCats", url.toString())

    const res = await fetch(url.toString(), {
        headers: {
            'x-api-key': API_KEY
        },
        cache: 'no-store'
    })
    if (!res.ok) {
        throw new Error("Failed to search")
    }
    const data = await res.json();
    console.log("searchCats",data)
    return data.reference_image_id;
    //return data.map((cat: any) => cat.reference_image_id);
}
/**getCatDetailsByRefId takes the id from searchCats and returns image details */
const getCatDetailsByRefId = async (id: string | null | undefined): Promise<Cat> => {
    console.log("getCatDetailsByRefId--->",id)
    const res = await fetch(`${BASE_URL}/images/${id}`, {
        headers: {
            'x-api-key': API_KEY
        },
        cache: 'no-store'

    })
    if (!res.ok) {
        throw new Error("Failed to fetch cats");
    }
    // console.log("getCatDetailsByRefId",res.json())
    return res.json()
}

export const searchBreeds = async (breedId?: string | null) => {
    console.log("searchBreeds", breedId)
    const id = await searchCats(breedId);
   //  console.log("ids---------------->", ids)
    // const cats = await getCatDetailsByRefId(breedId);
    // console.log("**********",cats)
    // return cats;
     const cats = await getCatDetailsByRefId(id);
     console.log("**********",cats)
    return cats;
}