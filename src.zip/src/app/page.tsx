import styles from "./page.module.css";
import CatGrid from "@/components/CatGrid";
import { getCats } from "./../actions/getCats";
import { getBreeds } from "@/actions/getBreeds";

export const revalidate = 60;

const CatHomePage = async () => {

  const initialList = await getCats(0,12);
  return (
    <main style={{ padding: "2rem" }}>
      {/* <h1>I am lost in all these cuteness</h1> */}
      <CatGrid initialList={initialList} />
    </main>
  );
}

export default CatHomePage;